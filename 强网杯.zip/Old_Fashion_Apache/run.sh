docker run  -p "0.0.0.0:30080:80" -p "0.0.0.0:38000:8000" --privileged --name=bb1ar old_fashion_apache
