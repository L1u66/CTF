docker build -t "old_fashion_apache" .
